package prPrakBD_bagain1_2;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class App extends Application {

    private TableView<employeeSalary> table = new TableView<>();

    @Override
    public void start(Stage Stage) {
        TableColumn<employeeSalary, String> FullNameCol = new TableColumn<>("Full Name");
        FullNameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        TableColumn<employeeSalary, Double> SalaryCol = new TableColumn<>("Salary");
        SalaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));

        TableColumn<employeeSalary, Double> comPctCol = new TableColumn<>("Commission Percentage");
        comPctCol.setCellValueFactory(new PropertyValueFactory<>("commissionPct"));

        TableColumn<employeeSalary, Double> commissionCol = new TableColumn<>("Commission");
        commissionCol.setCellValueFactory(new PropertyValueFactory<>("commission"));

        TableColumn<employeeSalary, Double> totalSalaryCol = new TableColumn<>("Total Salary");
        totalSalaryCol.setCellValueFactory(new PropertyValueFactory<>("totalSalary"));

        table.getColumns().addAll(FullNameCol, SalaryCol, comPctCol, commissionCol, totalSalaryCol);


        loadData();

        VBox root = new VBox(table);
        Scene scene = new Scene(root, 600, 400);
        Stage.setScene(scene);
        Stage.setTitle("Employee List");
        Stage.show();
    }

    private void loadData() {
        ObservableList<employeeSalary> employeesData = FXCollections.observableArrayList();

        try (Connection conn = connection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM employees")) {

           while(rs.next()){
               String firstName = rs.getString("first_name");
               String lastName = rs.getString("last_name");
               double salary = rs.getDouble("salary");
               double commissionPct = rs.getDouble("commission_pct");
               employeesData.add(new employeeSalary(firstName, lastName,salary,commissionPct));
           }

        } catch (Exception e) {
            e.printStackTrace();
        }

        table.setItems(employeesData);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
