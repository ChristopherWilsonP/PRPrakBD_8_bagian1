package prPrakBD_bagain1_2;

public class employeeSalary {
    private String fullName;
    private double commissionPct;
    private double  salary;
    private double totalSalary;
    private double commission;

    public employeeSalary(String firstName, String lastName, double salary, double commissionPct){
        this.fullName = firstName+" "+lastName;
        this.salary = salary;
        this.commissionPct = commissionPct;
        this.commission = salary*commissionPct;
        this.totalSalary = salary + commission;
    }

    public String getFullName() {
        return fullName;
    }

    public double getCommissionPct() {
        return commissionPct;
    }

    public double getSalary() {
        return salary;
    }

    public double getTotalSalary() {
        return totalSalary;
    }

    public double getCommission() {
        return commission;
    }
}
