package com.example.prprakbd_8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connection {
    private static final String URL = "jdbc:postgresql://localhost:5432/PraktikumBD_8";
    private static final String USER = "postgres";
    private static final String PASSWORD = "Christopher1610";

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}