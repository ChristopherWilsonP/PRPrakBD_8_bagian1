module com.example.prprakbd_8 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    exports prPrakBD_bagain1_2;
    opens com.example.prprakbd_8 to javafx.fxml;
    exports com.example.prprakbd_8;
}
